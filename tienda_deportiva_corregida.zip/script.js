
// Función para agregar productos al carrito
function addToCart(product) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

// Función para mostrar los productos en el carrito
function updateCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    let total = 0;
    cart.forEach(product => {
        const li = document.createElement('li');
        li.textContent = `${product.name} - $${product.price}`;
        cartItems.appendChild(li);
        total += product.price;
    });

    document.getElementById('total').textContent = `Total: $${total}`;
}

// Llamar a la función para mostrar el carrito al cargar la página
document.addEventListener('DOMContentLoaded', updateCart);
    